package managePortfolio.enums;

public enum SIPStatus {
    ACTIVE, IN_ACTIVE;
}
