package managePortfolio.enums;

public enum PortfolioRequestTypes {
    ALLOCATE, SIP, CHANGE, BALANCE, RE_BALANCE;
}
