package managePortfolio.util;

import java.util.ArrayList;
import java.util.List;

public class PortfolioUtility {
    public static List<Double> getAllocationsPercentages(Double quity, Double debt,Double gold){
        Double totalFunds = debt+gold+quity;
        List<Double> tempAllocations=new ArrayList<>();
        tempAllocations.add(quity/totalFunds);
        tempAllocations.add(debt/totalFunds);
        tempAllocations.add(gold/totalFunds);
        return tempAllocations;
    }
}
