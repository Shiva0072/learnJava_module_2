package managePortfolio.service;

public class PortfolioServiceManager {
    public static PortfolioService getPortfolioService(){
        return new PortfolioService();
    }
}
