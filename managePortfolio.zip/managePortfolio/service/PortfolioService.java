package managePortfolio.service;

import managePortfolio.dao.PortfolioDao;
import managePortfolio.entity.Portfolio;
import managePortfolio.entity.PortfolioByMonth;
import managePortfolio.enums.Months;
import managePortfolio.enums.SIPStatus;
import managePortfolio.portfolioRequest.AbstractPortfolioRequest;
import managePortfolio.util.PortfolioUtility;

import java.util.ArrayList;
import java.util.List;

public class PortfolioService {
    private static PortfolioDao myPortfolioDao;
    //myPortfolioDao would be common among all the objects of PortfolioService.

    public void allocatePortfolio(AbstractPortfolioRequest portfolioRequest){

        Double quity = portfolioRequest.getQuity();
        Double debt = portfolioRequest.getDebt();
        Double gold = portfolioRequest.getGold();
        Months month = portfolioRequest.getMonth();

        Portfolio newPortfolio = new Portfolio.Builder().
                currentQuityAmount(quity).
                currentDebtAmount(debt).
                currentGoldAmount(gold).
                build();

        myPortfolioDao = PortfolioDao.connectPortfolioDao(newPortfolio);

        myPortfolioDao.addInitialAllocations(PortfolioUtility.getAllocationsPercentages(quity,debt,gold));

        myPortfolioDao.addPortfolioOfAMonth(Months.JANUARY,buildPortfolioByMonthObject(month,quity,debt,gold));
    }

    public void changePorfolio(AbstractPortfolioRequest portfolioRequest){
        Months month = portfolioRequest.getMonth();

        Double quity = portfolioRequest.getQuity();
        Double debt = portfolioRequest.getDebt();
        Double gold = portfolioRequest.getGold();

        myPortfolioDao.doSIP(month);
        myPortfolioDao.makeChanges(month,quity,debt,gold);

        myPortfolioDao.addPortfolioOfAMonth(
                month,
                buildPortfolioByMonthObject(month,
                    myPortfolioDao.myPortfolio.getCurrentQuityAmount(),
                    myPortfolioDao.myPortfolio.getCurrentDebtAmount(),
                    myPortfolioDao.myPortfolio.getCurrentGoldAmount()
                )
        );


        if(month.ordinal()==Months.JUNE.ordinal() || month.ordinal()==Months.DECEMBER.ordinal()){

            //rebalancing
            myPortfolioDao.doReBalancing(month);
            myPortfolioDao.addPortfolioOfAMonth(
                    month,
                    buildPortfolioByMonthObject(
                            month,
                            myPortfolioDao.myPortfolio.getCurrentQuityAmount(),
                            myPortfolioDao.myPortfolio.getCurrentDebtAmount(),
                            myPortfolioDao.myPortfolio.getCurrentGoldAmount()
                    )
            );
        }
    }

    private PortfolioByMonth buildPortfolioByMonthObject(Months month,Double quity,Double debt, Double gold){
        return new PortfolioByMonth.Builder().
                currentQuityAmount(quity).
                currentDebtAmount(debt).
                currentGoldAmount(gold).
                month(month).
                build();
    }

    public void AddSIP(AbstractPortfolioRequest portfolioRequest){
        Double quity = portfolioRequest.getQuity();
        Double debt = portfolioRequest.getDebt();
        Double gold = portfolioRequest.getGold();
        Months month = portfolioRequest.getMonth();

        List<Double> sipAllocations = new ArrayList<>();
        sipAllocations.add(quity);
        sipAllocations.add(debt);
        sipAllocations.add(gold);

        myPortfolioDao.AddSIP(sipAllocations);
    }

    public PortfolioByMonth currentBalance(AbstractPortfolioRequest portfolioRequest){
        Months month = portfolioRequest.getMonth();
        PortfolioByMonth portfolioByMonth = myPortfolioDao.myPortfolio.getPortfolioSchedule().get(month);
        return portfolioByMonth;
    }

    public PortfolioByMonth ReBalance(){

        if(myPortfolioDao.myPortfolio.getPortfolioSchedule().containsKey(Months.DECEMBER)){
            return myPortfolioDao.myPortfolio.getPortfolioSchedule().get(Months.DECEMBER);
        }

        else if(myPortfolioDao.myPortfolio.getPortfolioSchedule().containsKey(Months.JUNE)){
            return myPortfolioDao.myPortfolio.getPortfolioSchedule().get(Months.JUNE);
        }

        return null;
    }

    private void printAmounts(Portfolio portfolio, Months month){
        Double quity = portfolio.getCurrentQuityAmount();
        Double debt =portfolio.getCurrentDebtAmount();
        Double gold = portfolio.getCurrentGoldAmount();
        SIPStatus currentStatus = portfolio.getSipStatus();
        PortfolioByMonth currentPortfolio = portfolio.getPortfolioSchedule().get(month);

        System.out.println("=====going to update=====");
        System.out.println(quity+ " "+ debt+" "+gold);
        System.out.println("My month : "+month);
        System.out.println(
                month+"'s "+" last deposits were "+currentPortfolio.getCurrentQuityAmount()+" "+
                currentPortfolio.getCurrentDebtAmount()+ " "+
                currentPortfolio.getCurrentGoldAmount()
        );
        System.out.println("=========END========\n");
    }

}
