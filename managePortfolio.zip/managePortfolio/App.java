package managePortfolio;

import managePortfolio.entity.Entity;
import managePortfolio.portfolioFactory.PortfolioRequestFactory;
import managePortfolio.portfolioRequest.AbstractPortfolioRequest;
import managePortfolio.service.PortfolioServiceManager;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

//https://codu.ai/coding-problem/MyMoney
public class App {
    public static void main(String args[]) throws FileNotFoundException {

        ///// INPUT
        String filePath_1="/Users/Shivam.Verma/Downloads/ledger-service/app/src/main/java/managePortfolio/resources/Example_1.txt";
        String filePath_2="/Users/Shivam.Verma/Downloads/ledger-service/app/src/main/java/managePortfolio/resources/Example_2.txt";

        Scanner scanner = new Scanner(new File(filePath_2));
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();

            AbstractPortfolioRequest requestObject= PortfolioRequestFactory.servePortfolioRequest(line);

            switch (requestObject.getPortfolioRequestTypes()){
                case ALLOCATE:
                    PortfolioServiceManager.getPortfolioService().allocatePortfolio(requestObject);
                    System.out.println();
                    break;
                case SIP:
                    PortfolioServiceManager.getPortfolioService().AddSIP(requestObject);
                    System.out.println();
                    break;
                case CHANGE:
                    PortfolioServiceManager.getPortfolioService().changePorfolio(requestObject);
                    System.out.println();
                    break;
                case BALANCE:
                    Entity portfolioByMonth = PortfolioServiceManager.getPortfolioService().currentBalance(requestObject);
                    printPortfolio(portfolioByMonth);
                    break;
                case RE_BALANCE:
                    Entity portfolio = PortfolioServiceManager.getPortfolioService().ReBalance();
                    printPortfolio(portfolio);
                    break;
                default:
                    System.out.println("WRONG INPUT\n");;
            }

        }
    }

    static void testingPortfolioRequestObjects(){
        String cmd1 = "ALLOCATE 6000 3000 1000";
        String cmd2 = "SIP 2000 1000 500" ;
        String cmd3 = "CHANGE 4.00% 10.00% 2.00% JUNE";
        String cmd4 = "BALANCE MARCH";
        String cmd5 = "REBALANCE";
        AbstractPortfolioRequest requestObject= PortfolioRequestFactory.servePortfolioRequest(cmd3);
        System.out.println(requestObject.verifyMeByPrinting());
    }

    static void printPortfolio(Entity portfolio){

        if(portfolio==null){
            System.out.println("CANNOT_REBALANCE");
            return;
        }

        System.out.println(
                (int)Math.floor(portfolio.getCurrentQuityAmount())+" "+
                (int)Math.floor(portfolio.getCurrentDebtAmount())+" "+
                (int)Math.floor(portfolio.getCurrentGoldAmount())
        );
    }

}
