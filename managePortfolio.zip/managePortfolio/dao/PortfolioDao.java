package managePortfolio.dao;

import managePortfolio.entity.Portfolio;
import managePortfolio.entity.PortfolioByMonth;
import managePortfolio.enums.Months;
import managePortfolio.enums.SIPStatus;

import java.util.List;

public class PortfolioDao {
    private static PortfolioDao portfolioDao;
    public Portfolio myPortfolio;

    private PortfolioDao(Portfolio portfolio) {
        this.myPortfolio = portfolio;
    }

    public static PortfolioDao connectPortfolioDao(Portfolio portfolio) {
        if (portfolioDao == null) {
            portfolioDao = new PortfolioDao(portfolio);
        }
        return portfolioDao;
    }

    public void addInitialAllocations(List<Double> initialAllocations){
        myPortfolio.setInitialAllocations(initialAllocations);
    }

    public void addPortfolioOfAMonth(Months month,PortfolioByMonth portfolioByMonth){
        myPortfolio.getPortfolioSchedule().put(month,portfolioByMonth);
    }

    public void AddSIP(List<Double> sipAllocations){

        myPortfolio.setSipStatus(SIPStatus.ACTIVE);
        myPortfolio.setSipAllocations(sipAllocations);

    }

    public void doSIP(Months month){
        if(myPortfolio.getSipStatus()==SIPStatus.IN_ACTIVE || month==Months.JANUARY) return;

        List<Double> sipAllocations = myPortfolio.getSipAllocations();

        myPortfolio.setCurrentQuityAmount(myPortfolio.getCurrentQuityAmount()+sipAllocations.get(0));
        myPortfolio.setCurrentDebtAmount(myPortfolio.getCurrentDebtAmount()+sipAllocations.get(1));
        myPortfolio.setCurrentGoldAmount(myPortfolio.getCurrentGoldAmount()+sipAllocations.get(2));

    }

    public void makeChanges(Months month,Double quity,Double debt, Double gold){

        Double currentQuity = myPortfolio.getCurrentQuityAmount();
        Double currentDebtAmount = myPortfolio.getCurrentDebtAmount();
        Double currentGoldAmount = myPortfolio.getCurrentGoldAmount();

        myPortfolio.setCurrentQuityAmount(currentQuity + currentQuity*quity);
        myPortfolio.setCurrentDebtAmount(currentDebtAmount + currentDebtAmount*debt);
        myPortfolio.setCurrentGoldAmount(currentGoldAmount + currentGoldAmount*gold);
    }


    public void doReBalancing(Months month) {

            List<Double> initialAllocations = myPortfolio.getInitialAllocations();

            Double quity = myPortfolio.getCurrentQuityAmount();
            Double debt = myPortfolio.getCurrentDebtAmount();
            Double gold = myPortfolio.getCurrentGoldAmount();


            Double total = quity + debt + gold;

            myPortfolio.setCurrentQuityAmount(total * initialAllocations.get(0));
            myPortfolio.setCurrentDebtAmount(total * initialAllocations.get(1));
            myPortfolio.setCurrentGoldAmount(total * initialAllocations.get(2));
    }

    private void printAmounts(Portfolio portfolio, Months month){
        Double quity = portfolio.getCurrentQuityAmount();
        Double debt =portfolio.getCurrentDebtAmount();
        Double gold = portfolio.getCurrentGoldAmount();
        SIPStatus currentStatus = portfolio.getSipStatus();
        PortfolioByMonth currentPortfolio = portfolio.getPortfolioSchedule().get(month);

        System.out.println("=====going to update=====");
        System.out.println(quity+ " "+ debt+" "+gold);
        System.out.println("My month : "+month);
        System.out.println(
                month+"'s "+" last deposits were "+currentPortfolio.getCurrentQuityAmount()+" "+
                        currentPortfolio.getCurrentDebtAmount()+ " "+
                        currentPortfolio.getCurrentGoldAmount()
        );
        System.out.println("SIP status : "+portfolio.getSipStatus());
        System.out.println("=========END========\n");
    }

}
/*
*
* since object of PortfolioDao is not created everytime (and only a single instance of it is maintained), so myPortfolio remains same everytime we access it.
*
* Note: PortfolioDao is class variable and myPortfolio is instance variable.
*
* */