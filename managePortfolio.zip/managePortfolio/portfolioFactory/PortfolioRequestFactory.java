package managePortfolio.portfolioFactory;

import managePortfolio.enums.Months;
import managePortfolio.portfolioRequest.*;

public class PortfolioRequestFactory {
    public static AbstractPortfolioRequest servePortfolioRequest(String command){
        //Factory Design Pattern
        String[] args = command.split(" ");

        switch (args[0]){
            case "ALLOCATE" :
                return new AllocateRequest.Builder().
                        quity(Double.valueOf(args[1])).
                        debt(Double.valueOf(args[2])).
                        gold(Double.valueOf(args[3])).
                        build();

            case "SIP":
                return new SIPRequest.Builder().
                        quity(Double.valueOf(args[1])).
                        debt(Double.valueOf(args[2])).
                        gold(Double.valueOf(args[3])).
                        build();

            case "CHANGE":
                return new ChangeRequest.Builder().
                        quity((Double.valueOf(args[1].replace("%", "")))/100).
                        debt((Double.valueOf(args[2].replace("%", "")))/100).
                        gold((Double.valueOf(args[3].replace("%", "")))/100).
                        month(Months.valueOf(args[4].toUpperCase())).
                        build();

            case "BALANCE":
                return new BalanceRequest.Builder().
                        month(Months.valueOf(args[1].toUpperCase())).
                        build();


            case "REBALANCE":;
                return new RebalanceRequest.Builder().build();

            default: return null;
        }
    }

}
