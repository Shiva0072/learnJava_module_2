package managePortfolio.portfolioRequest;

import managePortfolio.enums.PortfolioRequestTypes;

public class ChangeRequest extends AbstractPortfolioRequest{

    public ChangeRequest(Builder b){
        super(b);
    }

    public static class Builder extends AbstractPortfolioRequest.Builder<ChangeRequest, Builder>{

        public Builder(){
            super(PortfolioRequestTypes.CHANGE);
        }
        @Override
        public Builder self(){
            return this;
        }
        @Override
        public ChangeRequest build(){
            return new ChangeRequest(this);
        }
    }

    @Override
    public String verifyMeByPrinting(){
        return "AbstractPortfolioRequest{" +
                "portfolioRequestTypes=" + this.portfolioRequestTypes +
                ", month='" + this.month + '\'' +
                ", quity=" + this.quity +
                ", debt=" + this.debt +
                ", gold=" + this.gold +
                '}';
    }

}
