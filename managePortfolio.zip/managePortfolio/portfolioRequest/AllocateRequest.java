package managePortfolio.portfolioRequest;

import managePortfolio.enums.Months;
import managePortfolio.enums.PortfolioRequestTypes;

public class AllocateRequest extends AbstractPortfolioRequest{

    public AllocateRequest(Builder b){
        super(b);
    }

    public static class Builder extends AbstractPortfolioRequest.Builder<AllocateRequest,Builder>{

        public Builder(){
            super(PortfolioRequestTypes.ALLOCATE);
            this.month(Months.JANUARY);
        }
        @Override
        public Builder self(){
            return this;
        }
        @Override
        public AllocateRequest build(){
            return new AllocateRequest(this);
        }
    }

}
