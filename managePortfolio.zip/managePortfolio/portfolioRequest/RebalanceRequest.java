package managePortfolio.portfolioRequest;

import managePortfolio.enums.PortfolioRequestTypes;

public class RebalanceRequest extends AbstractPortfolioRequest{

    public RebalanceRequest(Builder b){
        super(b);
    }

    public static class Builder extends AbstractPortfolioRequest.Builder<RebalanceRequest,Builder>{

        public Builder(){
            super(PortfolioRequestTypes.RE_BALANCE);
        }
        @Override
        public Builder self(){ return this;}

        @Override
        public RebalanceRequest build(){ return new RebalanceRequest(this);}
    }
}
