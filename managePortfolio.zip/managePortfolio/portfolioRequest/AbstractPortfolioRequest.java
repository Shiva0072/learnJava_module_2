package managePortfolio.portfolioRequest;

import com.org.loanledger.request.AbstractRequest;
import managePortfolio.enums.Months;
import managePortfolio.enums.PortfolioRequestTypes;

public abstract class AbstractPortfolioRequest {
    protected PortfolioRequestTypes portfolioRequestTypes;
    protected Months month;
    protected double quity;
    protected double debt;
    protected double gold;

    public AbstractPortfolioRequest(Builder<?,?> b){
        this.portfolioRequestTypes=b.portfolioRequestTypes;
        this.month=b.month;
        this.gold=b.gold;
        this.quity=b.quity;
        this.debt=b.debt;
    }

    public static abstract class Builder<T extends AbstractPortfolioRequest,E extends Builder<T,E>>{
        public PortfolioRequestTypes portfolioRequestTypes;
        public Months month;
        public double quity;
        public double gold;
        public double debt;

        Builder(PortfolioRequestTypes portfolioRequestTypes){
            this.portfolioRequestTypes = portfolioRequestTypes;
        }

        public abstract E self();
        public abstract T build();

        public E month(Months month){
            this.month=month;
            return self();
        }
        public E quity(double quity){
            this.quity=quity;
            return self();
        }
        public E gold(double gold){
            this.gold=gold;
            return self();
        }
        public E debt(double debt){
            this.debt=debt;
            return self();
        }

    }

    public PortfolioRequestTypes getPortfolioRequestTypes() {
        return portfolioRequestTypes;
    }

    public Months getMonth() {
        return month;
    }

    public double getQuity() {
        return quity;
    }

    public double getDebt() {
        return debt;
    }

    public double getGold() {
        return gold;
    }

    public String verifyMeByPrinting(){
        return "AbstractPortfolioRequest{" +
                "portfolioRequestTypes=" + this.portfolioRequestTypes +
                ", month='" + this.month + '\'' +
                ", quity=" + this.quity +
                ", debt=" + this.debt +
                ", gold=" + this.gold +
                '}';
    }
}
