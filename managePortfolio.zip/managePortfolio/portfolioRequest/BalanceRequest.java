package managePortfolio.portfolioRequest;

import managePortfolio.enums.PortfolioRequestTypes;

public class BalanceRequest extends AbstractPortfolioRequest{

    public BalanceRequest(Builder b){
        super(b);
    }

    public static class Builder extends AbstractPortfolioRequest.Builder<BalanceRequest, Builder>{

        public Builder(){
            super(PortfolioRequestTypes.BALANCE);
        }
        @Override
        public Builder self(){
            return this;
        }
        @Override
        public BalanceRequest build(){
            return new BalanceRequest(this);
        }
    }
}
