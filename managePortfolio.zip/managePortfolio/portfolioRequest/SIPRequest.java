package managePortfolio.portfolioRequest;

import CloneLoanLedger.enums.RequestType;
import managePortfolio.enums.Months;
import managePortfolio.enums.PortfolioRequestTypes;
import managePortfolio.enums.SIPStatus;

public class SIPRequest extends AbstractPortfolioRequest{
    private SIPStatus sipStatus;
    public SIPRequest(Builder b){
        super(b);
        this.sipStatus=b.sipStatus;
    }

    public static class Builder extends AbstractPortfolioRequest.Builder<SIPRequest,Builder>{
        private SIPStatus sipStatus;

        public Builder(){
            super(PortfolioRequestTypes.SIP);
            this.sipStatus=SIPStatus.ACTIVE;
            this.month= Months.FEBRUARY;
        }

        @Override
        public SIPRequest build(){
            return new SIPRequest(this);
        }

        @Override
        public Builder self(){
            return this;
        }
    }

    @Override
    public String verifyMeByPrinting(){
        return "AbstractPortfolioRequest{" +
                "portfolioRequestTypes=" + this.portfolioRequestTypes +
                ", SIP_STATUS ='"+this.sipStatus+'\''+
                ", month='" + this.month + '\'' +
                ", quity=" + this.quity +
                ", debt=" + this.debt +
                ", gold=" + this.gold +
                '}';
    }

}
