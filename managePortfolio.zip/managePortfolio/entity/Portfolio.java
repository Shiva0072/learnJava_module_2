package managePortfolio.entity;

import managePortfolio.enums.Months;
import managePortfolio.enums.SIPStatus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Portfolio extends Entity{
    protected SIPStatus sipStatus;
    protected List<Double> initialAllocations;
    protected Map<Months, PortfolioByMonth> portfolioSchedule;
    protected List<Double> sipAllocations;

    public Portfolio(Builder b){
        super(b);
        sipStatus=b.sipStatus;
        initialAllocations=b.initialAllocations;
        portfolioSchedule=b.portfolioSchedule;
        sipAllocations = b.sipAllocations;
    }

    public static class Builder extends Entity.Builder<Portfolio,Builder>{
        protected SIPStatus sipStatus;
        protected List<Double> initialAllocations;
        protected Map<Months, PortfolioByMonth> portfolioSchedule;
        protected List<Double> sipAllocations;

        public Builder(){
            super();
            sipStatus=SIPStatus.IN_ACTIVE;
            initialAllocations = new ArrayList<>();
            portfolioSchedule = new HashMap<>();
            sipAllocations=new ArrayList<>();
        }

        @Override
        public Portfolio build(){
            return new Portfolio(this);
        }
        @Override
        public Builder self(){
            return this;
        }

    }

    public SIPStatus getSipStatus() {
        return sipStatus;
    }

    public void setSipStatus(SIPStatus sipStatus) {
        this.sipStatus = sipStatus;
    }

    public List<Double> getInitialAllocations() {
        return initialAllocations;
    }

    public void setInitialAllocations(List<Double> initialAllocations) {
        this.initialAllocations = initialAllocations;
    }

    public Map<Months, PortfolioByMonth> getPortfolioSchedule() {
        return portfolioSchedule;
    }

    public void setPortfolioSchedule(Map<Months, PortfolioByMonth> portfolioSchedule) {
        this.portfolioSchedule = portfolioSchedule;
    }

    public List<Double> getSipAllocations() {
        return sipAllocations;
    }

    public void setSipAllocations(List<Double> sipAllocations) {
        this.sipAllocations = sipAllocations;
    }

    public String verifyMeByPrinting() {
        return "Portfolio_Entity{" +
                "equityAmount=" + currentQuityAmount +
                ", debtAmount=" + currentDebtAmount +
                ", goldAmount=" + currentGoldAmount +
                '}';
    }

}
