package managePortfolio.entity;

public abstract class Entity {
    protected Double currentQuityAmount;
    protected Double currentDebtAmount;
    protected Double currentGoldAmount;
    public Entity(Builder<?,?> b){
        this.currentDebtAmount=b.currentDebtAmount;
        this.currentQuityAmount=b.currentQuityAmount;
        this.currentGoldAmount=b.currentGoldAmount;
    }

    public abstract static class Builder<E extends Entity,T extends Builder<E,T>>{
        //Buider Design Pattern
        private Double currentQuityAmount;
        private Double currentDebtAmount;
        private Double currentGoldAmount;

        public Builder(){}

        public abstract T self();
        public abstract E build();

        public T currentQuityAmount(Double equity){
            this.currentQuityAmount=equity;
            return self();
        }

        public T currentDebtAmount(Double debt){
            this.currentDebtAmount=debt;
            return self();
        }

        public T currentGoldAmount(Double gold){
            this.currentGoldAmount=gold;
            return self();
        }
    }

    public Double getCurrentQuityAmount() {
        return currentQuityAmount;
    }

    public void setCurrentQuityAmount(Double currentQuityAmount) {
        this.currentQuityAmount = currentQuityAmount;
    }

    public Double getCurrentDebtAmount() {
        return currentDebtAmount;
    }

    public void setCurrentDebtAmount(Double currentDebtAmount) {
        this.currentDebtAmount = currentDebtAmount;
    }

    public Double getCurrentGoldAmount() {
        return currentGoldAmount;
    }

    public void setCurrentGoldAmount(Double currentGoldAmount) {
        this.currentGoldAmount = currentGoldAmount;
    }
}
