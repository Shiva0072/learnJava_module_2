package managePortfolio.entity;

import managePortfolio.enums.Months;

public class PortfolioByMonth extends Entity{
    protected Months month;

    public PortfolioByMonth(Builder b){
        super(b);
        this.month=b.month;
    }

    public static class Builder extends Entity.Builder<PortfolioByMonth,Builder>{
        private Months month;

        public Builder(){
            super();
        }

        @Override
        public Builder self(){
            return this;
        }
        @Override
        public PortfolioByMonth build(){
            return new PortfolioByMonth(this);
        }

        public Builder month(Months month){
            this.month=month;
            return self();
        }
    }

    public Months getMonth() {
        return month;
    }

    public String verifyMeByPrinting() {
        return "PortfolioByMonth_Entity{" +
                "equityAmount=" + currentQuityAmount +
                ", debtAmount=" + currentDebtAmount +
                ", goldAmount=" + currentGoldAmount +
                '}';
    }
}
